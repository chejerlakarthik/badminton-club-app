import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
export declare class BadmintonClubAppStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps);
}
//# sourceMappingURL=badminton-club-app-stack.d.ts.map