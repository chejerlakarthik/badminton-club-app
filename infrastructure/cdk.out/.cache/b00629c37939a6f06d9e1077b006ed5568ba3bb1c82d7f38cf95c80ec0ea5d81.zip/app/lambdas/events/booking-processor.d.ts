import { EventBridgeEvent } from 'aws-lambda';
export declare const handler: (event: EventBridgeEvent<string, any>) => Promise<void>;
//# sourceMappingURL=booking-processor.d.ts.map